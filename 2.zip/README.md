# LiveGuard AI — HID Hackathon

Run this kiosk on the laptop connected to the demo webcam. The simulated door checks for liveness, compares a face to the claimed Campus ID, and checks a signed access schedule. It runs locally after dependencies and models are installed.

## Run locally

Use Python 3.12 and a current Chromium or Chrome browser. Commands below use Bash on Linux or macOS. On Windows, use a local Python 3.12 install with PowerShell environment-variable syntax, and install `tzdata` if the system lacks IANA timezone data.

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python models.py
python -m unittest discover -s tests -v
python policy.py --signer-dir state/demo-signer --subject demo-user
read -rsp 'Choose an operator token with 16 or more characters: ' LIVEGUARD_OPERATOR_TOKEN
echo
export LIVEGUARD_OPERATOR_TOKEN
python -m uvicorn app:app --host 127.0.0.1 --port 8000
```

Open [http://localhost:8000](http://localhost:8000). Start the camera, enter `demo-user`, expand **Operator enrollment**, enter the token, confirm consent and click **Enroll campus ID**. Center the face with even lighting and click **Verify access**. Re-enter the operator token to remove the enrollment. Close the browser tab when finished.

The setup policy authorizes `demo-user` for the full local day and expires after eight hours. Reissue the policy to change access without restarting the server. The signer path above is a convenience for a single-machine demo. Use a separate operator-controlled location when demonstrating separation of kiosk and signer.

```bash
# Repeat --subject to authorize additional enrolled IDs.
python policy.py --signer-dir state/demo-signer --subject demo-user \
  --timezone Asia/Kolkata --start-minute 540 --end-minute 1080 --ttl 28800
# Demonstrate explicit schedule denial by issuing a policy with no authorized IDs.
python policy.py --signer-dir state/demo-signer
# Restore demo access before testing the other scenarios.
python policy.py --signer-dir state/demo-signer --subject demo-user
```

## Measure the HID demo

1. Capture consenting volunteers and physical print and screen presentations through the demo webcam. Show the live enrolled person, the wrong person claiming the same ID, poor lighting and a guided retake. Use the same enrolled ID for the print and screen trials to test whether PAD protects a potentially matching identity.
2. Use a calibration set distinct from the scored trials by subject or capture session where possible. If you adjust thresholds, restart the kiosk with `LIVEGUARD_LIVE_MIN`, `LIVEGUARD_SPOOF_MAX`, `LIVEGUARD_MATCH_MIN`, and `LIVEGUARD_MISMATCH_MAX`. Record the hardware and freeze thresholds before final scoring.
3. In **Evaluation**, set the scenario before each attempt, then export the session CSV. Aim for at least 20 initial attempts per headline scenario where feasible. Keep each initial attempt and retake, and record the print medium, display, lighting and capture distance in test notes. Do not pool the three attack types.
4. Run `python evaluate.py liveguard-session.csv`. It reports browser p50/p95/max, backend p95 where present, deadline misses, PAD outcomes, uncertain results and attack acceptance. Include the device and sample counts with the results. Use PAD pass on attacks as an APCER-style measure and spoof classification on bona fide captures as a BPCER-style measure, stating explicitly how uncertain decisions were handled. Report access false accepts/rejects separately from PAD and mark scenarios without observations as untested.
5. Disconnect the network after setup and demonstrate a valid signed policy. Issue a one-second policy with `--ttl 1` to demonstrate expiry, then restore the regular policy. Sync queued audit events after reconnecting.

## AWS sandbox

Use the organizer-provided account, credentials and allowed region. The workstation needs AWS CLI and AWS SAM CLI. The sandbox must allow CloudFormation/SAM, deployment artifact storage, API Gateway, Lambda, DynamoDB, and IAM role creation or a suitable preapproved role.

```bash
export AWS_REGION='YOUR_ALLOWED_REGION'
aws sts get-caller-identity
sam validate --lint --template-file aws/template.yaml --region "$AWS_REGION"
sam build --template-file aws/template.yaml
sam deploy --guided --stack-name liveguard-hid --region "$AWS_REGION" --capabilities CAPABILITY_IAM
```

During guided deployment, use a sandbox-approved artifact bucket or SAM-managed bucket if allowed. Use the stack's **AuditUrl** output. The caller role needs `execute-api:Invoke` for POST on that route, and a separate operator can verify a row using the **AuditTableName** output and read access. An unsigned request should receive an authorization error.

```bash
python sync_audit.py --url 'AUDIT_URL_FROM_STACK_OUTPUT' --region "$AWS_REGION"
```

Replaying the same event ID yields one DynamoDB row. The kiosk's sync command retains rows after transport failures and can be rerun. Seven-day expiration is applied by DynamoDB TTL. The AWS deployment contains the audit service and uses no webcam data or identity templates. The kiosk UI and inference run on the laptop.

## Models and provenance

`python models.py` downloads SHA-256-verified YuNet, SFace and two MiniFASNet variants. The ZIP contains source code, so the first setup requires network access. Use [YuNet's MIT notice](https://huggingface.co/opencv/face_detection_yunet/blob/main/LICENSE), [SFace's Apache-2.0 license](https://huggingface.co/opencv/face_recognition_sface/blob/main/LICENSE) and [MiniFASNet's upstream Apache-2.0 license](https://github.com/minivision-ai/Silent-Face-Anti-Spoofing/blob/master/LICENSE). Exports and checksums come from [V2](https://huggingface.co/garciafido/minifasnet-v2-anti-spoofing-onnx) and the [V1SE manifest](https://huggingface.co/e96031413/mobilevlm-app-models/blob/main/manifest-v1.json). The upstream implementation, model initialization and sample checks govern preprocessing. See the revised architecture for observed results and unverified acceptance criteria.
