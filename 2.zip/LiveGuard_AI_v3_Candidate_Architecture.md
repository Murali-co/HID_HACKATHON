# LiveGuard AI 3.0 — HID hackathon prototype architecture

**Status** — Implemented local baseline. Physical webcam acceptance and AWS sandbox deployment are pending.  
**Hardware assumption** — One ordinary laptop or USB RGB webcam and a CPU kiosk. The prototype displays a simulated access decision.

## HID requirements and acceptance

| Requirement | Implementation | Acceptance evidence |
|---|---|---|
| Liveness plus identity | Dual-crop MiniFASNet presentation attack detection (PAD) and SFace 1:1 match against the claimed Campus ID | Live enrolled volunteer, different enrolled or consenting volunteer claiming that ID, and capture-quality cases |
| Decision within two seconds | Warm local models, short browser burst, backend budget check and two-second browser timeout | On the demo laptop, record time from Verify access click through the UI decision update. Include capture, encoding, loopback transport, inference, policy and audit. Report p50, p95, max and the count over two seconds. Also record PAD and server timing separately if needed. |
| At least two spoof types | Evaluate printed photo and phone-displayed still. Add phone video replay if time allows. | Physical presentations to the same camera, with per-type trial counts, results and p95. Mark masks untested unless physically evaluated. |
| ALLOW, REQUEST VERIFICATION, DENY | Server evaluates PAD, identity and access schedule. One guided retake is offered for uncertainty. | Show each state, one successful retake and one retake that cannot establish access. |
| AWS sandbox | API Gateway HTTP API, Lambda and DynamoDB for deduplicated minimal audit ingestion | Deploy in the organizers' permitted region. Show a kiosk audit event synced to DynamoDB and a duplicate event producing one row. |

## Revised stack

| Layer | Selected implementation | Reason |
|---|---|---|
| Capture and UI | Same-origin HTML/CSS/JavaScript served by FastAPI on localhost | Browser webcam permissions, no frontend build step, and no CDN dependency for offline operation |
| Quality and detection | OpenCV 4.12 headless with YuNet ONNX | Lightweight face detection and five landmarks; explicit one-face, framing, light and focus checks |
| PAD | MiniFASNet V2 (2.7×) and V1SE (4.0×) via ONNX Runtime CPU across three frames | Use the upstream pretrained pair, require cross-crop and cross-frame agreement for a pass, and route conflicting evidence to verification |
| Identity | OpenCV SFace ONNX with alignment and cosine scoring | Public model license and one OpenCV dependency. InsightFace's bundled pretrained weights have non-commercial research terms. |
| Policy and templates | Ed25519 signed local policy, SQLite, AES-256-GCM sealed templates | Keep decisions independent of network and separate verified identity from permission |
| AWS | AWS SAM, IAM-authenticated HTTP API, Lambda, encrypted DynamoDB with TTL | Audit sync stays outside the camera path. SigV4 uses the sandbox role. |
| Evaluation | Browser CSV and Python CLI | Count uncertain results and retakes explicitly and report per scenario |

The candidate's MobileNetV3, TinyViT, learned fusion, cloud liveness and calibrated IR/depth move to later experiments. Add one branch at a time only after collecting data, then compare held-out PAD and latency against this baseline. AWS Rekognition Face Liveness is an online alternative with a separate prompted capture workflow. Browser camera capture does not establish physical-camera provenance. RGB mask resistance and managed camera integration require their own evidence.

## Decision flow

```mermaid
flowchart TD
    A["Claimed ID and three camera frames"] --> B["YuNet and capture quality"]
    B --> C["MiniFASNet V2 and V1SE"]
    C -->|Live| D["SFace 1:1 identity match"]
    C -->|Spoof| F["Deny"]
    B -->|Poor capture| G["Request verification"]
    C -->|Uncertain| G
    D -->|Mismatch| F
    D -->|Borderline| G
    D -->|Match| E["Verify policy, time and schedule"]
    E -->|Authorized| H["Allow"]
    E -->|Explicit denial| F
    E -->|Unavailable| G
    G --> I["Guided retake with policy recheck"]
```

The kiosk checks the policy for each decision, including uncertain attempts. A definitive spoof or explicit access denial takes precedence. An initial uncertain result may issue a subject-bound token valid for 30 seconds and one retake. If the retake remains uncertain, access is denied and the operator can assist. A browser timeout shows REQUEST VERIFICATION and requires a fresh scan. Only an in-budget successful response can display ALLOW.

MiniFASNet receives unaligned BGR crops resized to 80×80, NCHW float32 in 0–255. The source implementation keeps the raw pixel range for NumPy inputs. Apply softmax once and use class index 1 for liveness. Never infer the physical attack type from the class index. The kiosk uses the least confident crop/frame for the live gate, and requires both crops to show low live scores in at least two frames to return SPOOF, with no strongly live score in the burst. PAD defaults are .85 and .25. Identity uses the minimum cosine score across three aligned crops compared to the normalized enrollment centroid. Identity defaults are .50 for a match and below .35 for mismatch. These are starting thresholds for the demo. Tune on calibration attempts and freeze before held-out testing. Scores are uncalibrated.

## Offline and data handling

The same locally issued snapshot governs online and offline decisions in this baseline. It binds Campus IDs to one door and same-day access windows. The signer has a separate private key directory and the kiosk reads the public key and signed envelope. An invalid, missing or expired snapshot blocks ALLOW. The demo detects a wall-clock discontinuity within the running process. A deployment with unattended access would need protected time, protected signing keys, policy refresh and rollback protection.

Operator enrollment requires explicit consent and a configured operator token. The local SQLite database stores the encrypted template and minimal audit queue. Camera frames remain in memory. The encryption key is stored in a permission-restricted local file for the supervised demo. The AWS route receives only a UUID, UTC timestamp and access outcome. Pending rows remain local until acknowledged. DynamoDB uses a conditional insert keyed by event ID. CSV exports exclude identities, frames and templates. Local enrollment removal is available through the operator panel.

## Verification record

- Python 3.12 CPU model dependencies installed, all five model files verified by SHA-256, and all four models initialized.
- Ten automated tests passed, including three-way decisions, single-use retake, signed policy expiry and tampering, clock discontinuity, encrypted enrollment and audit deduplication logic.
- Real-model, in-process API smoke test used upstream sample JPEGs repeated as burst frames. The enrolled sample returned ALLOW. The other genuine sample returned DENY for identity mismatch. Of six spoof-labeled fixtures, three returned DENY and three requested verification. This small smoke set does not establish attack type coverage or accuracy. Across 32 in-process calls, p50 was 35.6 ms and p95 was 79.3 ms. Browser capture and rendering were outside that measurement.
- SAM translation with a placeholder packaged S3 URI produced an AWS_IAM-protected route. AWS credentials and physical webcam trials were unavailable in this environment. A Chromium launch was blocked by the execution sandbox, so browser camera interaction and UI-to-decision timing remain unverified.

## Primary references

- [HID Hackathon challenge](https://tinyurl.com/hid-hackathon), supplied poster
- [OpenCV DNN face detection and recognition tutorial](https://docs.opencv.org/doc/doxygen/html/d0/dd4/tutorial_dnn_face.html)
- [OpenCV Zoo YuNet model](https://huggingface.co/opencv/face_detection_yunet) and [SFace license](https://huggingface.co/opencv/face_recognition_sface/blob/main/LICENSE)
- [MiniFASNet upstream scoring and class mapping](https://github.com/minivision-ai/Silent-Face-Anti-Spoofing/blob/master/test.py) and [upstream NumPy transform](https://github.com/minivision-ai/Silent-Face-Anti-Spoofing/blob/b6d5f04ad78778917853b25c778acef6d5626d15/src/data_io/functional.py)
- [InsightFace pretrained model terms](https://github.com/deepinsight/insightface/blob/master/python-package/docs/model_zoo.md)
- [MDN browser camera capture](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia)
- [AWS SAM HTTP API authorization](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/sam-property-httpapi-httpapiauth.html), [DynamoDB conditional writes](https://docs.aws.amazon.com/amazondynamodb/latest/APIReference/API_PutItem.html) and [AWS Rekognition Face Liveness](https://docs.aws.amazon.com/rekognition/latest/dg/face-liveness.html)
